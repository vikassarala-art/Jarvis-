package com.jarvis.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.text.InputType
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var logView: TextView
    private lateinit var statusView: TextView
    private lateinit var accView: TextView
    private lateinit var keyInput: EditText
    private lateinit var textInput: EditText
    private lateinit var langBtn: Button
    private lateinit var contBox: CheckBox
    private lateinit var scroll: ScrollView

    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private lateinit var brain: Brain
    private val handler = Handler(Looper.getMainLooper())
    private var lang = "en-IN"
    private var busy = false
    private var awake = false
    private var wakeRequired = false

    private val prefs by lazy { getSharedPreferences("jarvis", Context.MODE_PRIVATE) }
    private val wakeRegex = Regex("(?i)(hey |hi |ok |okay )?(jarvis|జార్విస్|జార్వీస్)[,.!]?\\s*")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        brain = Brain(PhoneTools(applicationContext))
        lang = prefs.getString("lang", "en-IN") ?: "en-IN"
        buildUi()
        updLang()

        tts = TextToSpeech(this) { s -> ttsReady = (s == TextToSpeech.SUCCESS) }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                runOnUiThread { afterSpeech() }
            }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                runOnUiThread { afterSpeech() }
            }
        })

        requestPermissions(
            arrayOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.CALL_PHONE,
                Manifest.permission.READ_CONTACTS
            ), 1
        )
    }

    override fun onResume() {
        super.onResume()
        accView.text = if (JarvisAccessibilityService.instance != null)
            "Phone control: ON ✅" else "Phone control: OFF ⚠️ (enable Accessibility)"
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(14), dp(40), dp(14), dp(14))
        root.setBackgroundColor(Color.parseColor("#06101C"))

        val title = TextView(this)
        title.text = "J.A.R.V.I.S"
        title.textSize = 22f
        title.setTextColor(Color.parseColor("#27D3FF"))
        title.gravity = Gravity.CENTER

        keyInput = EditText(this)
        keyInput.hint = "Anthropic API key (sk-ant-...)"
        keyInput.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        keyInput.setTextColor(Color.WHITE)
        keyInput.setHintTextColor(Color.GRAY)
        keyInput.setText(prefs.getString("key", ""))

        val saveBtn = Button(this)
        saveBtn.text = "Save key"
        saveBtn.setOnClickListener {
            prefs.edit().putString("key", keyInput.text.toString().trim()).apply()
            say("Key saved, sir.")
        }

        val accBtn = Button(this)
        accBtn.text = "Enable phone control (Accessibility)"
        accBtn.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }

        langBtn = Button(this)
        langBtn.setOnClickListener {
            lang = if (lang == "en-IN") "te-IN" else "en-IN"
            prefs.edit().putString("lang", lang).apply()
            updLang()
        }

        contBox = CheckBox(this)
        contBox.text = "Hands-free: say 'Hey Jarvis' (keep app open)"
        contBox.setTextColor(Color.WHITE)
        contBox.setOnCheckedChangeListener { _, checked ->
            if (checked) {
                wakeRequired = true
                awake = false
                listen()
            } else {
                recognizer?.cancel()
                status("Ready, sir.")
            }
        }

        accView = TextView(this)
        accView.setTextColor(Color.parseColor("#FFB347"))
        statusView = TextView(this)
        statusView.setTextColor(Color.parseColor("#7FA3BF"))
        statusView.text = "Ready, sir."

        logView = TextView(this)
        logView.setTextColor(Color.parseColor("#DFF3FF"))
        logView.textSize = 15f
        scroll = ScrollView(this)
        scroll.addView(logView)

        val micBtn = Button(this)
        micBtn.text = "🎙"
        micBtn.setOnClickListener {
            wakeRequired = false
            awake = false
            listen()
        }
        textInput = EditText(this)
        textInput.hint = "Type here…"
        textInput.setTextColor(Color.WHITE)
        textInput.setHintTextColor(Color.GRAY)
        val sendBtn = Button(this)
        sendBtn.text = "➤"
        sendBtn.setOnClickListener {
            val t = textInput.text.toString().trim()
            if (t.isNotEmpty()) {
                textInput.setText("")
                process(t)
            }
        }
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.addView(micBtn)
        row.addView(textInput, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(sendBtn)

        root.addView(title)
        root.addView(keyInput)
        root.addView(saveBtn)
        root.addView(accBtn)
        root.addView(langBtn)
        root.addView(contBox)
        root.addView(accView)
        root.addView(statusView)
        root.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(row)
        setContentView(root)
    }

    private fun updLang() {
        langBtn.text = if (lang == "en-IN") "Language: English (tap for తెలుగు)" else "భాష: తెలుగు (tap for English)"
    }

    private fun status(s: String) {
        statusView.text = s
    }

    private fun log(s: String) {
        logView.append(s + "\n\n")
        scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    private fun say(s: String) {
        log("🤖 " + s)
        speak(s)
    }

    private fun speak(text: String) {
        if (!ttsReady) {
            afterSpeech()
            return
        }
        val telugu = text.any { it in '\u0C00'..'\u0C7F' }
        tts?.language = if (telugu) Locale("te", "IN") else Locale("en", "IN")
        tts?.speak(text.replace("*", ""), TextToSpeech.QUEUE_FLUSH, null, "jv")
    }

    private fun afterSpeech() {
        if (contBox.isChecked && !busy) listen()
    }

    private fun listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            log("Speech recognition ee phone lo available ledu.")
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            return
        }
        tts?.stop()
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { status(if (wakeRequired) "Say 'Hey Jarvis'…" else "Listening…") }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onError(error: Int) {
                if (contBox.isChecked && error != SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                    handler.postDelayed({ if (contBox.isChecked && !busy) listen() }, 900)
                } else {
                    status("Ready, sir.")
                }
            }
            override fun onResults(results: Bundle?) {
                val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (t.isNullOrBlank()) {
                    if (contBox.isChecked) listen() else status("Ready, sir.")
                } else {
                    handleHeard(t.trim())
                }
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
        r.startListening(i)
    }

    private fun handleHeard(text: String) {
        if (!wakeRequired) {
            process(text)
            return
        }
        val m = wakeRegex.find(text)
        if (m == null) {
            if (awake) {
                awake = false
                process(text)
            } else {
                listen()
            }
            return
        }
        val rest = text.removeRange(m.range).trim()
        if (rest.isEmpty()) {
            awake = true
            say("Yes, sir?")
        } else {
            awake = false
            process(rest)
        }
    }

    private fun process(text: String) {
        if (busy) return
        val key = prefs.getString("key", "") ?: ""
        if (key.isBlank()) {
            say("Modatiga API key save cheyyandi, sir.")
            return
        }
        busy = true
        log("🧑 " + text)
        status("Thinking…")
        Thread {
            val reply = try {
                brain.ask(text, key) { step -> runOnUiThread { log("⚙ " + step) } }
            } catch (e: Exception) {
                "Error: " + e.message
            }
            runOnUiThread {
                busy = false
                status("Ready, sir.")
                say(reply)
            }
        }.start()
    }
}
