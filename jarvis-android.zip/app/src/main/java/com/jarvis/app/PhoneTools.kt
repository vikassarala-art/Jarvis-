package com.jarvis.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class PhoneTools(private val ctx: Context) {

    private fun launch(i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }

    private fun has(p: String): Boolean =
        ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    private fun tool(
        name: String,
        desc: String,
        vararg props: Pair<String, String>,
        required: List<String> = emptyList()
    ): JSONObject {
        val p = JSONObject()
        for ((k, t) in props) p.put(k, JSONObject().put("type", t))
        val schema = JSONObject()
            .put("type", "object")
            .put("properties", p)
            .put("required", JSONArray(required))
        return JSONObject().put("name", name).put("description", desc).put("input_schema", schema)
    }

    fun schema(): JSONArray {
        val a = JSONArray()
        a.put(tool("open_app", "Open an installed app by name, e.g. WhatsApp, Camera, Chrome, Settings, YouTube, PhonePe.", "name" to "string", required = listOf("name")))
        a.put(tool("call", "Call a phone number or a saved contact by name.", "contact" to "string", "number" to "string"))
        a.put(tool("send_sms", "Open the SMS app with a drafted message to a contact or number. The user taps send.", "contact" to "string", "number" to "string", "text" to "string", required = listOf("text")))
        a.put(tool("whatsapp", "Open WhatsApp chat with a drafted message to a contact or number. The user taps send.", "contact" to "string", "number" to "string", "text" to "string", required = listOf("text")))
        a.put(tool("flashlight", "Turn the flashlight on or off.", "on" to "boolean", required = listOf("on")))
        a.put(tool("set_volume", "Set volume. stream is music, ring or alarm. percent 0-100.", "stream" to "string", "percent" to "number", required = listOf("percent")))
        a.put(tool("set_alarm", "Set a real phone alarm. 24-hour clock.", "hour" to "number", "minute" to "number", "label" to "string", required = listOf("hour", "minute")))
        a.put(tool("set_timer", "Start a phone countdown timer in seconds.", "seconds" to "number", "label" to "string", required = listOf("seconds")))
        a.put(tool("open_settings", "Open a settings screen. page is one of: wifi, internet, bluetooth, airplane, display, sound, volume, location, battery, apps, nfc, hotspot, main. Android does not let apps toggle these directly; after opening, use tap_text to flip the switch if the user asked.", "page" to "string", required = listOf("page")))
        a.put(tool("open_url", "Open a web link in the browser.", "url" to "string", required = listOf("url")))
        a.put(tool("search_maps", "Search a place or get directions in Google Maps.", "query" to "string", required = listOf("query")))
        a.put(tool("play_music", "Search and play a song, artist or video on YouTube.", "query" to "string", required = listOf("query")))
        a.put(tool("web_search", "Search Google in the browser.", "query" to "string", required = listOf("query")))
        a.put(tool("battery", "Get battery percentage."))
        a.put(tool("get_time", "Get current date and time."))
        a.put(tool("read_screen", "Read the visible text on the current screen (needs accessibility). Use it to see what is on screen before tapping."))
        a.put(tool("tap_text", "Tap the on-screen button or item that shows this text (needs accessibility).", "text" to "string", required = listOf("text")))
        a.put(tool("scroll", "Scroll the current screen. direction is down or up.", "direction" to "string", required = listOf("direction")))
        a.put(tool("type_text", "Type text into the currently focused input box (needs accessibility).", "text" to "string", required = listOf("text")))
        a.put(tool("global_action", "System action: home, back, recents, notifications, quick_settings, lock, screenshot, power_dialog (needs accessibility).", "action" to "string", required = listOf("action")))
        return a
    }

    fun run(name: String, i: JSONObject): String {
        return try {
            when (name) {
                "open_app" -> openApp(i.optString("name"))
                "call" -> call(i)
                "send_sms" -> sms(i)
                "whatsapp" -> whatsapp(i)
                "flashlight" -> flash(i.optBoolean("on"))
                "set_volume" -> volume(i.optString("stream", "music"), i.optInt("percent", 50))
                "set_alarm" -> {
                    launch(
                        Intent(AlarmClock.ACTION_SET_ALARM)
                            .putExtra(AlarmClock.EXTRA_HOUR, i.optInt("hour"))
                            .putExtra(AlarmClock.EXTRA_MINUTES, i.optInt("minute"))
                            .putExtra(AlarmClock.EXTRA_MESSAGE, i.optString("label", "Jarvis"))
                            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                    )
                    "Alarm set"
                }
                "set_timer" -> {
                    launch(
                        Intent(AlarmClock.ACTION_SET_TIMER)
                            .putExtra(AlarmClock.EXTRA_LENGTH, i.optInt("seconds", 60))
                            .putExtra(AlarmClock.EXTRA_MESSAGE, i.optString("label", "Jarvis"))
                            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                    )
                    "Timer started"
                }
                "open_settings" -> settings(i.optString("page", "main"))
                "open_url" -> {
                    launch(Intent(Intent.ACTION_VIEW, Uri.parse(i.optString("url"))))
                    "Opened"
                }
                "search_maps" -> {
                    launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/search/?api=1&query=" + enc(i.optString("query")))))
                    "Maps opened"
                }
                "play_music" -> {
                    launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + enc(i.optString("query")))))
                    "YouTube opened"
                }
                "web_search" -> {
                    launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + enc(i.optString("query")))))
                    "Search opened"
                }
                "battery" -> {
                    val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
                    "Battery " + bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) + "%"
                }
                "get_time" -> SimpleDateFormat("EEEE, d MMM yyyy, hh:mm a", Locale.getDefault()).format(Date())
                "read_screen" -> acc { it.readScreen() }
                "tap_text" -> acc { if (it.clickText(i.optString("text"))) "Tapped" else "Not found on screen" }
                "scroll" -> acc { if (it.scroll(i.optString("direction") != "up")) "Scrolled" else "Cannot scroll" }
                "type_text" -> acc { if (it.typeText(i.optString("text"))) "Typed" else "No focused text box" }
                "global_action" -> acc { if (it.global(i.optString("action"))) "Done" else "Failed" }
                else -> "Unknown tool"
            }
        } catch (e: Exception) {
            "Error: " + e.message
        }
    }

    private fun acc(f: (JarvisAccessibilityService) -> String): String {
        val s = JarvisAccessibilityService.instance
            ?: return "Accessibility service is OFF. Ask the user to enable Jarvis in Accessibility settings."
        return f(s)
    }

    private fun openApp(q: String): String {
        val query = q.lowercase()
        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = pm.queryIntentActivities(main, 0)
        val m = list.firstOrNull { it.loadLabel(pm).toString().lowercase() == query }
            ?: list.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(query) }
            ?: return "App not found"
        val l = pm.getLaunchIntentForPackage(m.activityInfo.packageName) ?: return "Cannot launch"
        launch(l)
        return "Opened " + m.loadLabel(pm)
    }

    private fun findNumber(name: String): String? {
        if (!has(Manifest.permission.READ_CONTACTS)) return null
        val phone = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val cursor = ctx.contentResolver.query(
            phone,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
            arrayOf("%" + name + "%"),
            null
        )
        cursor?.use { c ->
            if (c.moveToFirst()) return c.getString(0)
        }
        return null
    }

    private fun target(i: JSONObject): String? {
        val n = i.optString("number", "")
        if (n.isNotBlank()) return n
        val c = i.optString("contact", "")
        return if (c.isNotBlank()) findNumber(c) else null
    }

    private fun call(i: JSONObject): String {
        val num = target(i) ?: return "No number or contact found (check contacts permission)"
        val action = if (has(Manifest.permission.CALL_PHONE)) Intent.ACTION_CALL else Intent.ACTION_DIAL
        launch(Intent(action, Uri.parse("tel:" + Uri.encode(num))))
        return "Calling " + num
    }

    private fun sms(i: JSONObject): String {
        val num = target(i) ?: return "No number or contact found"
        launch(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(num))).putExtra("sms_body", i.optString("text")))
        return "SMS draft opened, user must tap send"
    }

    private fun whatsapp(i: JSONObject): String {
        val raw = target(i) ?: return "No number or contact found"
        var digits = raw.filter { it.isDigit() }
        if (digits.length == 10) digits = "91" + digits
        launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/" + digits + "?text=" + enc(i.optString("text")))))
        return "WhatsApp draft opened, user must tap send"
    }

    private fun flash(on: Boolean): String {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return "No flashlight"
        cm.setTorchMode(id, on)
        return if (on) "Flashlight on" else "Flashlight off"
    }

    private fun volume(stream: String, pct: Int): String {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val s = when (stream.lowercase()) {
            "ring" -> AudioManager.STREAM_RING
            "alarm" -> AudioManager.STREAM_ALARM
            else -> AudioManager.STREAM_MUSIC
        }
        val max = am.getStreamMaxVolume(s)
        am.setStreamVolume(s, max * pct.coerceIn(0, 100) / 100, 0)
        return "Volume set to " + pct + "%"
    }

    private fun settings(page: String): String {
        val action = when (page.lowercase()) {
            "wifi" -> Settings.ACTION_WIFI_SETTINGS
            "internet" -> Settings.Panel.ACTION_INTERNET_CONNECTIVITY
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "airplane" -> Settings.ACTION_AIRPLANE_MODE_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS
            "volume" -> Settings.Panel.ACTION_VOLUME
            "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
            "apps" -> Settings.ACTION_APPLICATION_SETTINGS
            "nfc" -> Settings.ACTION_NFC_SETTINGS
            "hotspot" -> Settings.ACTION_WIRELESS_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        launch(Intent(action))
        return "Opened " + page + " settings"
    }
}
